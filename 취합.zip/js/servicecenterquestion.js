window.onload=function(){
   //질문 클릭
   $(function(){
        $('.qnaarea').click(function(){
             $('.answerarea').toggle();   
         });
    });
}    